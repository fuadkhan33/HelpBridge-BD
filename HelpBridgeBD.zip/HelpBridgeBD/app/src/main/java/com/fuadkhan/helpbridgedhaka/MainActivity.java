package com.fuadkhan.helpbridgedhaka;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity {
    Thread thread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void openHospital(View v){
        Intent intent = new Intent(this,HospitalActivity.class);
        startActivity(intent);
    }
    public void openFireService(View v){
        Intent intent = new Intent(this,FireServiceActivity.class);
        startActivity(intent);
    }
    public void openPolice(View v){
        Intent intent = new Intent(this,PoliceActivity.class);
        startActivity(intent);
    }
    public void openRab(View v){
        Intent intent = new Intent(this,RabActivity.class);
        startActivity(intent);
    }
    public void openSos(View v){
        Intent intent = new Intent(this,SosActivity.class);
        startActivity(intent);
    }



}
