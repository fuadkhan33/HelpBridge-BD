package com.fuadkhan.helpbridgedhaka;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class AppDatabase  {
    public final String DB_TABLE_FIRE_SERVICE = "fireService";
    public final String DB_TABLE_HOSPITAL = "hospital";
    public final String DB_TABLE_RAB = "rab";
    public final String DB_TABLE_POLICE = "police";
    public final String ID_COLUM = "id";
    public final String NAME_COLUMN = "name";
    public final String PHONE_NUMBER_COLUM = "phoneNumber";


    private final String DATABASE_NAME = "HelpBrigeAppDatabase";
    private final int DATABASE_VERSION = 1;

    SQLiteDatabase ourDatabase;
    DbHelper dbHelper;
    Context ourContext;

    public class DbHelper extends SQLiteOpenHelper {

        public DbHelper(Context context) throws SQLException{
            super(context, DATABASE_NAME, null, DATABASE_VERSION);

        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sqlCmd1 = "CREATE TABLE "+DB_TABLE_FIRE_SERVICE+"("
                    +ID_COLUM+ " INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    NAME_COLUMN +" VARCHAR(30),"+
                    PHONE_NUMBER_COLUM+" VARCHAR(20)"+
                    ");";
            db.execSQL(sqlCmd1);
            String sqlCmd2 = "CREATE TABLE "+DB_TABLE_HOSPITAL+"("
                    +ID_COLUM+ " INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    NAME_COLUMN +" VARCHAR(30),"+
                    PHONE_NUMBER_COLUM+" VARCHAR(20)"+
                    ");";
            db.execSQL(sqlCmd2);
            String sqlCmd3 = "CREATE TABLE "+DB_TABLE_POLICE+"("
                    +ID_COLUM+ " INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    NAME_COLUMN +" VARCHAR(30),"+
                    PHONE_NUMBER_COLUM+" VARCHAR(20)"+
                    ");";
            db.execSQL(sqlCmd3);
            String sqlCmd4 = "CREATE TABLE "+DB_TABLE_RAB+"("
                    +ID_COLUM+ " INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    NAME_COLUMN +" VARCHAR(30),"+
                    PHONE_NUMBER_COLUM+" VARCHAR(20)"+
                    ");";
            db.execSQL(sqlCmd4);
            db.execSQL("Delete from "+DB_TABLE_POLICE);
            db.execSQL("Delete from "+DB_TABLE_RAB);
            db.execSQL("Delete from "+DB_TABLE_HOSPITAL);
            db.execSQL("Delete from "+DB_TABLE_POLICE);
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Romna (Dhaka)','01713373125');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dhanamandi (Dhaka)','01713373126');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sahabaga (Dhaka)','01713373127');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('New Market (Dhaka)','01713373128');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lalabag (Dhaka)','01713373134');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotayali (Dhaka)','01713373135');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Hajaribag (Dhaka)','01713373136');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kamarangiracara (Dhaka)','01713373137');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sutraura (Dhaka)','01713373143');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Demara (Dhaka)','01713373144');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Syamapura (Dhaka)','01713373145');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jatrabari (Dhaka)','01713373146');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Motijhil (Dhaka)','01713373152');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sabujabaga (Dhaka)','01713373153');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Khilagao (Dhaka)','01713373154');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Paltana (Dhaka)','01713373155');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Uttara (Dhaka)','01713373161');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Eyaraporta (Dhaka)','01713373162');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Turaga (Dhaka)','01713373163');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Uttarakhana (Dhaka)','01713373164');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Daksinakhana (Dhaka)','01713373165');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Gulasana (Dhaka)','01713373171');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kyantanamenta (Dhaka)','01713373172');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Badda(Dhaka)','01713373173');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Khilakseta (Dhaka)','01713373174');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tejagao (Dhaka)','01713373180');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mohammadapura (Dhaka)','01713373182');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adabara (Dhaka)','01713373183');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mirapura (Dhaka)','01713373189');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Pallabi (Dhaka)','01713373190');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kapharula (Dhaka)','01713373191');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shah ali(Dhaka)','01713373192');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Savar','01713373327');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dhamarai ','01713373328');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('keraniganja ','01713373329');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nababaganja ','01713373330');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dohara ','01713373331');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('asuliya ','01713373332');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Southern keraniganj','01713373333');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('narayanaganja ','01713373345');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phatulla ','01713373346');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ports ','01713373347');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('siddiraganja ','01713373348');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('araihajara ','01713373349');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sonaragao ','01713373350');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rupaganja ','01713373351');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Joydebpur ','01713373363');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tangi ','01713373364');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kaliyakaira ','01713373365');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sripura ','01713373366');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kapasiya ','01713373367');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kaliganja','01713373368');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('manikaganja ','01713373379');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ghiora ','01713373380');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sibalaya ','01713373381');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('daulatapura ','01713373382');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('hariramapura ','01713373383');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('saturiya ','01713373384');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('singaira ','01713373385');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('munsiganja ','01713373396');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tangibari ','01713373397');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lauhajam ','01713373398');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('srinagara ','01713373399');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sirajadikhana ','01713373400');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gajariya ','01713373401');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('narasindi ','01713373412');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rayapura ','01713373413');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sibapura ','01713373414');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('belabo ','01713373415');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('manoharadi ','01713373416');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('palasa ','01713373417');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotwali police mayamanasinha','01713373430');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('muktagacha ','01713373431');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phulabari ','01713373432');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('trisala ','01713373433');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gauripura ','01713373434');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('isbaraganja ','01713373435');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nandaila ','01713373436');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phulapura ','01713373437');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('haluyaghata ','01713373438');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dhobaura ','01713373439');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gapharagao ','01713373440');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhaluka ','01713373441');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tarakanda ','01713373442');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tangaila ','01713373454');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mirjapura ','01713373455');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nagarapura ','01713373456');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sakhipura ','01713373457');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('basaila ','01713373458');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('deladuyara ','01713373459');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madhupura ','01713373460');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ghataila ','01713373461');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kalihati ','01713373462');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhuyapura ','01713373463');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jamuna Bridge East','01713373464');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dhanabari ','01713373465');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gopalapura ','01713373466');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kishoreganj ','01713373480');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('karimaganja ','01713373481');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('taraila ','01713373482');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('hosenapura ','01713373483');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('katiyadi','01713373484');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bajitapura ','01713373485');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kuliyaracara ','01713373486');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhairaba ','01713373487');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('itana ','01713373488');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mithamaina ','01713373489');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nikali ','01713373490');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pakundiya ','01713373491');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('astagrama ','01713373492');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('netrakona ','01713373505');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('barahatta ','01713373506');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kalamakanda ','01713373507');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('atapara ','01713373508');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('durgapura ','01713373509');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('purbadhala ','01713373510');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kenduya ','01713373511');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madana ','01713373512');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mohanaganja ','01713373513');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('khalijuri ','01713373514');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('serapura ','01713373523');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nakala ','01713373524');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nalitabari ','');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sribardi ','01713373526');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jhinaigati ','01713373527');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jamalapura ','01713373538');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('melandaha ','01713373539');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sarisabari ','01713373540');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('deoyanaganja ','01713373541');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('isalamapura ','01713373542');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madaraganja ','01713373543');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bakasiganja ','01713373544');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bahadurabada ','01713373545');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values(' Kotwali police pharidapura','01713373556');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madhukhali ','01713373557');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('boyalamari ','01713373558');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('alaphadanga ','alaphadanga ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('carabhadrasana ','01713373560');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nagarakanda ','01713373561');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sadarapura ','01713373562');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('salata ','01713373563');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhanga ','01713373564');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gopalaganja ','01713373572');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('makasudapura ','01713373573');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kasiyani ','01713373574');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kotalipara ','01713373575');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tungipara ','01713373576');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madaripura ','01713373585');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rajaira ','01713373586');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kalakini ','01713373587');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sibacara ','01713373588');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rajabari ','01713373598');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('baliyakandi ','01713373599');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pansa ','01713373600');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('goyalanda ','01713373601');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gosairahata ','01713373612');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhedaraganja ','01713373613');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('damudda ','01713373614');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jajira ','01713373615');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nariya ','01713373616');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('palam ','01713373617');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sakhipura ','01713373618');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotwali police(Barisal)','01713374267');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('hijala (Barisal)','01713374268');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mehediganja (Barisal)','01713374269');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('muladi (Barisal)','01713374270');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('babuganja (Barisal)','01713374271');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bakeraganja (Barisal)','01713374272');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('agaulajhara (Barisal)','01713374274');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gauranadi (Barisal)','01713374275');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ujirapura (Barisal)','01713374276');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jhalakathi (Barisal)','01713374286');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nalachithi (Barisal)','01713374287');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rajapura (Barisal)','01713374288');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kathaliya (Barisal)','01713374289');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhola (Barisal)','01713374300');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('daulatakhana (Barisal)','01713374301');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tajumuddina (Barisal)','01713374302');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('borahanauddina (Barisal)','01713374303');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lalamohana (Barisal)','01713374304');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('caraphyasana(Barisal)','01713374305 ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('manapura (Barisal)','01713374306');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('patuyakhali (Barisal)','01713374318');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bauphala (Barisal)','01713374319');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('galacipa (Barisal)','01713374320');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dasamina (Barisal)','01713374321');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dumaki (Barisal)','01713374322');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kalapara (Barisal)','01713374323');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mirjaganja (Barisal)','01713374324');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rangabali (Barisal)','01713374325');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pirojapura (Barisal)','01713374336');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhandariya (Barisal)','01713374337');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nesarabada (Barisal)','01713374338');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kaukhali (Barisal)','01713374339');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('najirapura (Barisal)','01713374340');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Zia nagara(Barisal)','01713374341');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mathabariya (Barisal)','01713374342');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('baraguna (Barisal)','01713374353');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('amatali (Barisal)','01713374354');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('patharaghata (Barisal)','01713374355');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('betagi (Barisal)','01713374356');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bamana (Barisal)','01713374357');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('talatali (Barisal)','01713374358');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotwali (Sylhet)','Kotwali ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('balaganja (Sylhet)','01713374376');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jaintapura (Sylhet)','01713374377');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('goyainaghata (Sylhet)','01713374378');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kanaighata (Sylhet)','01713374379');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kompaniganja (Sylhet)','01713374380');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jakiganja (Sylhet)','01713374381');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('biyanibajara (Sylhet)','01713374382');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('golapaganja (Sylhet)','01713374383');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bisbanatha (Sylhet)','01713374384');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phencuganja (Sylhet)','01713374385');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Southern surama (Sylhet)','01713374386');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Osmani nagara(Sylhet)','01713374387');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('habiganja (Sylhet)','01713374398');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madhabapura (Sylhet)','01713374399');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('cunarughata (Sylhet)','01713374400');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bahubala (Sylhet)','01713374401');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lakhai (Sylhet)','01713374402');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nabiganja (Sylhet)','01713374403');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('baniyacam(Sylhet)','01713374404 ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ajamiriganja (Sylhet)','01713374405');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sayestaganja (Sylhet)','01713374406');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sunamaganja (Sylhet)','01713374418');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('chataka (Sylhet)','01713374419');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jagannathapura (Sylhet)','01713374420');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tahirapura (Sylhet)','01713374421');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bisbambarapura (Sylhet)','01713374422');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('doyarabajara (Sylhet)','01713374423');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dirai (Sylhet)','01713374424');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('salana (Sylhet)','01713374425');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jamalaganja (Sylhet)','01713374426');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dharmapasa (Sylhet)','01713374427');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('madhyanagara (Sylhet)','01713374428');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('maulabhibajara (Sylhet)','01713374439');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('srimangala (Sylhet)','srimangala ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kamalaganja (Sylhet)','01713374441');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rajanagara (Sylhet)','01713374442');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kulaura (Sylhet)','01713374443');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('baralekha (Sylhet)','01713374444');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('juri (Sylhet)','01713374445');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotwali(Chittagong )','01713373256');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('in the mountains (North Zone)(Chittagong )','01713373257');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pacalaisa (Chittagong )','01713373258');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('candagao (Chittagong )','01713373259');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('khulasi (Chittagong )','01713373260');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bakuliya (Chittagong )','01713373261');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bayazid bostami(Chittagong )','01713373262');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ports (Chittagong )','01713373267');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Double murim(Chittagong )','01713373268');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('halisahara (Chittagong )','01713373269');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('patenga (Chittagong )','01713373270');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('karnaphuli (Chittagong )','01713373271');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Immigration Station (port) (Chittagong )','01713373272');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('the mountains (Port Zone)(Chittagong )','01713373273');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('raujana (Chittagong )','01713373639');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('hatahajari (Chittagong )','01713373640');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phatikachari (Chittagong )','01713373641');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ranguniya (Chittagong )','01713373642');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('patiya (Chittagong )','01713373643');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mirasarai (Chittagong )','01713373644');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sitakundu (Chittagong )','01713373645');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('anoyara (Chittagong )','01713373646');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('boyalakhali (Chittagong )','01713373647');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('basakhali (Chittagong )','01713373648');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('satakaniya (Chittagong )','01713373649');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lohagara (Chittagong )','01713373650');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('candanaisa (Chittagong )','01713373651');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sandipa (Chittagong )','01713373652');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values(' Cox’s Bazar(Chittagong )','01713373663');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ramu (Chittagong )','01713373664');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ukhiya (Chittagong )','01713373665');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tekanapha (Chittagong )','01713373666');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('cakoriya (Chittagong )','01713373667');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kutubadiya (Chittagong )','01713373668');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mahesakhali (Chittagong )','01713373669');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pekuya (Chittagong )','01713373670');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotwali kumilla(Chittagong )','01713373685');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('cauddagrama (Chittagong )','01713373686');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('debiddara (Chittagong )','01713373687');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('homana (Chittagong )','01713373688');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lakasama (Chittagong )','01713373689');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('daudakandi (Chittagong )','01713373690');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('buricam (Chittagong )','01713373691');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('candina (Chittagong )','01713373692');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('barura (Chittagong )','01713373693');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('langalakota (Chittagong )','01713373694');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('muradanagara (Chittagong )','01713373695');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('braksmanapara (Chittagong )','01713373696');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('meghana (Chittagong )','01713373697');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('manoharaganja (Chittagong )','01713373698');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('titasa (Chittagong )','01713373699');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Southern kumilla(Chittagong )','01713373700');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('cadapura (Chittagong )','01713373712');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('hajiganja (Chittagong )','01713373713');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('matalaba (Chittagong )','01713373714');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values(' plan for South(Chittagong )','01713373715');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('saharasti (Chittagong )','');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('(Chittagong )','01713373716');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kacuya (Chittagong )','01713373717');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pharidaganja (Chittagong )','01713373718');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('haimacara (Chittagong )','01713373719');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('braksmanabariya sadara(Chittagong )','01713373730');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('saraila (Chittagong )','01713373731');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('asuganja (Chittagong )','01713373732');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nasiranagara (Chittagong )','01713373733');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nabinagara (Chittagong )','01713373734');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bancharamapura (Chittagong )','01713373735');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kasaba (Chittagong )','01713373736');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Akhaura (Chittagong )','01713373737');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sudharam, noyakhali(Chittagong )','01713373748');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('begamaganja (Chittagong )','01713373749');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('senabaga (Chittagong )','01713373750');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sonaimuri (Chittagong )','01713373751');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kompaniganja (Chittagong )','01713373752');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('catakhila (Chittagong )','01713373753');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('hatiya (Chittagong )','01713373754');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('carajabbara (Chittagong )','01713373755');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('laksipura (Chittagong )','01713373765');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rayapura (Chittagong )','01713373766');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ramaganja (Chittagong )','01713373767');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ramagati (Chittagong )','01713373768');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('pheni (Chittagong )','01713373778');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sonagaji (Chittagong )','01713373779');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phulagaji (Chittagong )','01713373780');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('parasurama (Chittagong )','01713373781');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('chagalanaiya (Chittagong )','01713373782');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('daganabhuiya (Chittagong )','01713373783');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sonadanga (Khulna)','01713373286');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('khalisapura (Khulna)','01713373287');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('daulatapura (Khulna)','01713373288');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ali Khan Jahan(Khulna)','01713373289');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phulatala (Khulna)','01713374103');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dighaliya (Khulna)','01713374104');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('paikagacha (Khulna)','01713374105');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('batiyaghata (Khulna)','01713374106');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dumuriya (Khulna)','01713374107');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('terakhada (Khulna)','01713374108');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rupasa (Khulna)','01713374109');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dakopa (Khulna)','01713374110');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kayara (Khulna)','01713374111');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bagerahata (Khulna)','01713374122');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phakirahata (Khulna)','01713374123');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mollarahata (Khulna)','01713374124');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('citalamari (Khulna)','01713374125');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kacuya (Khulna)','01713374126');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('moralaganja (Khulna)','01713374127');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('saranakhola (Khulna)','01713374128');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('manla (Khulna)','01713374129');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ramapala (Khulna)','01713374130');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sataksira (Khulna)','01713374141');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tala (Khulna)','01713374143');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kaliganja (Khulna)','01713374144');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('syamanagara (Khulna)','01713374145');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('debahata (Khulna)','01713374146');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('asasuni (Khulna)','01713374147');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('patakelaghata (Khulna)','01713374148');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values(' Kotwali police(Khulna)','01713374161');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jhikaragacha (Khulna)','01713374162');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sarsa (Khulna)','01713374163');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('caugacha (Khulna)','01713374164');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('maniramapura (Khulna)','01713374165');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kesabapura (Khulna)','01713374166');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('abhayanagara (Khulna)','01713374167');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bagharapara (Khulna)','01713374168');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('port Benapole(Khulna)','01713374169');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bogura(Khulna)','01713374170 ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('magura (Khulna)','01713374179');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('salikha (Khulna)','01713374180');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sripura (Khulna)','01713374181');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mohammadapura (Khulna)','01713374182');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jhinaidaha (Khulna)','01713374192');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kaliganja (Khulna)','01713374193');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sailakupa (Khulna)','01713374194');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('harinakundu (Khulna)','01713374195');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kotacadapura (Khulna)','01713374196');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mahesapura (Khulna)','01713374197');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('naraila (Khulna)','01713374206');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kaliya (Khulna)','01713374207');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lohagara  (Khulna)','01713374208');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('naragati (Khulna)','01713374209');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kustiya (Khulna)','01713374220');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('khokasa (Khulna)','01713374221');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kumarakhali (Khulna)','01713374222');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bheramara (Khulna)','01713374223');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('daulatapura (Khulna)','01713374224');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mirapura (Khulna)','01713374225');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('OC of the Islamic University (Khulna)','01713374226');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('cuyadanga (Khulna)','01713374236');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('alamadanga (Khulna)','01713374237');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('jibananagara (Khulna)','01713374238');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('damurahuda (Khulna)','01713374239');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('meherapura (Khulna)','01713374249');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('ganni (Khulna)','01713374250');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mujibanagara (Khulna)','01713374251');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('boyaliya (Rajshahi)','01713373309');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('OC rajapara(Rajshahi)','01713373310');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('matihara (Rajshahi)','01713373311');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shah makaduma(Rajshahi)','01713373312');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('paba (Rajshahi)','01713373800');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('OC gudagari (Rajshahi)','01713373801');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('tanara (Rajshahi)','01713373802');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mohanapura (Rajshahi)','01713373803');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('puthiya (Rajshahi)','01713373804');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bagamara (Rajshahi)','01713373805');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('durgapura (Rajshahi)','01713373806');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('caraghata (Rajshahi)','01713373807');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bagha (Rajshahi)','01713373808');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('capai nababaganja(Rajshahi)','01713373819');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sibaganja (Rajshahi)','01713373820');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gomastapura (Rajshahi)','01713373821');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nacola (Rajshahi)','01713373822');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bholahata (Rajshahi)','01713373823');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('naoga (Rajshahi)','01713373836');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('rayanagara (Rajshahi)','01713373837');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('atrai (Rajshahi)','01713373838');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('dhamarai (Rajshahi)','01713373839');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('badalagachi (Rajshahi)','01713373840');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mahadebapura(Rajshahi)','01713373841 ');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('patanitala (Rajshahi)','01713373842');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('niyamatapura (Rajshahi)','01713373843');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('manda (Rajshahi)','01713373844');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sapahara (Rajshahi)','01713373845');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('parsa (Rajshahi)','01713373846');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('natora (Rajshahi)','01713373857');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sinra (Rajshahi)','01713373858');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('baghatipara (Rajshahi)','01713373859');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gurudasapura (Rajshahi)','01713373860');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('lalapura (Rajshahi)','01713373861');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('baraigrama (Rajshahi)','01713373862');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('naladanga (Rajshahi)','01713373863');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kotwali, Rangpu(Rajshahi)','');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('(Rajshahi)','01713373874');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gangacura (Rajshahi)','');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('(Rajshahi)','01713373875');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('bhodaraganja (Rajshahi)','01713373876');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('taraganja (Rajshahi)','01713373877');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('mithapukura (Rajshahi)','01713373878');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('piragacha (Rajshahi)','01713373879');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('kauniya (Rajshahi)','01713373880');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('piraganja (Rajshahi)','01713373881');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gaibandha (Rajshahi)','01713373892');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sadullapura (Rajshahi)','01713373893');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sundaraganja (Rajshahi)','01713373894');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('palasabari (Rajshahi)','01713373895');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('gobindaganja (Rajshahi)','01713373896');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('sataghata (Rajshahi)','01713373897');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('phulachari (Rajshahi)','01713373898');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('nilaphamari (Rajshahi)','01713373909');");
            db.execSQL("insert into "+DB_TABLE_POLICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('saiyadapura (Rajshahi)','01713373910');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-1)','01777710100');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-1)','01777710101');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-1)','01777710102');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-1)','01777710103');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-1)','01777710104');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-1)','01777710105');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-1)','01777710106');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-1)','01777710107');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-1)','01777710108');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-1)','01777710109');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-1)','01777710110');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-1)','01777710111');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-1)','01777710122');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-1)','01777710133');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-1)','01777710144');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-1)','01777710155');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-1)','01777710199');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-2)','01777710200');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-2)','01777710201');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-2)','01777710202');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-2)','01777710203');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-2)','01777710204');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-2)','01777710205');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-2)','01777710206');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-2)','01777710207');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-2)','01777710208');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-2)','01777710209');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-2)','01777710210');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-2)','01777710211');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-2)','01777710222');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-2)','01777710233');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-2)','01777710244');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-2)','01777710255');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-2)','01777710299');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-3)','01777710300');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-3)','01777710301');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-3)','01777710302');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-3)','01777710303');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-3)','01777710304');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-3)','01777710305');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-3)','01777710306');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-3)','01777710307');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-3)','01777710308');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-3)','01777710309');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-3)','01777710310');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-3)','01777710311');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-3)','01777710322');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-3)','01777710333');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-3)','01777710344');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-3)','01777710355');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-3)','01777710399');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-4)','01777710400');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-4)','01777710401');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-4)','01777710402');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-4)','01777710403');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-4)','01777710404');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-4)','01777710405');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-4)','01777710406');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-4)','01777710407');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-4)','01777710408');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-4)','01777710409');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-4)','01777710410');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-4)','01777710411');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-4)','01777710422');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-4)','01777710433');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-4)','01777710444');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-4)','01777710455');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-4)','01777710499');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-5)','01777710500');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-5)','01777710501');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-5)','01777710502');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-5)','01777710503');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-5)','01777710504');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-5)','01777710505');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-5)','01777710506');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-5)','01777710507');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-5)','01777710508');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-5)','01777710509');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-5)','01777710510');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-5)','01777710511');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-5)','01777710522');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-5)','01777710533');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-5)','01777710544');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-5)','01777710555');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-5)','01777710599');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-6)','01777710600');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-6)','01777710601');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-6)','01777710602');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-6)','01777710603');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-6)','01777710604');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-6)','01777710605');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-6)','01777710606');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-6)','01777710607');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-6)','01777710608');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-6)','01777710609');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-6)','01777710610');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-6)','01777710611');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-6)','01777710622');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-6)','01777710633');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-6)','01777710644');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-6)','01777710655');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-6)','01777710699');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-7)','01777710700');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-7)','01777710701');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-7)','01777710702');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-7)','01777710703');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-7)','01777710704');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-7)','01777710705');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-7)','01777710706');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-7)','01777710707');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-7)','01777710708');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-7)','01777710709');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-7)','01777710710');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-7)','01777710711');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-7)','01777710722');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-7)','01777710733');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-7)','01777710744');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-7)','01777710755');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-7)','01777710799');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-8)','01777710800');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-8)','01777710801');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-8)','01777710802');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-8)','01777710803');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-8)','01777710804');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-8)','01777710805');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-8)','01777710806');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-8)','01777710807');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-8)','01777710808');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-8)','01777710809');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-8)','01777710810');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-8)','01777710811');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-8)','01777710822');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-8)','01777710833');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-8)','01777710844');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-8)','01777710855');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-8)','01777710899');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-9)','01777710900');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-9)','01777710901');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-9)','01777710902');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-9)','01777710903');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-9)','01777710904');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-9)','01777710905');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-9)','01777710906');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-9)','01777710907');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-9)','01777710908');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-9)','01777710909');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-9)','01777710910');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-9)','01777710911');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-9)','01777710922');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-9)','01777710933');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-9)','01777710944');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-9)','01777710955');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-9)','01777710999');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-10)','01777711000');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-10)','01777711001');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-10)','01777711002');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-10)','01777711003');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-10)','01777711004');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-10)','01777711005');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-10)','01777711006');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-10)','01777711007');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-10)','01777711008');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-10)','01777711009');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-10)','01777711010');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-10)','01777711011');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-10)','01777711022');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-10)','01777711033');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-10)','01777711044');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-10)','01777711055');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-10)','01777711099');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-11)','01777711100');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-11)','01777711101');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-11)','01777711102');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-11)','01777711103');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-11)','01777711104');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-11)','01777711105');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-11)','01777711106');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-11)','01777711107');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-11)','01777711108');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-11)','01777711109');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-11)','01777711110');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-11)','01777711111');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-11)','01777711122');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-11)','01777711133');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-11)','01777711144');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-11)','01777711155');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-11)','01777711199');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-12)','01777711200');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-12)','01777711201');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-12)','01777711202');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-12)','01777711203');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-12)','01777711204');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-12)','01777711205');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-12)','01777711206');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-12)','01777711207');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-12)','01777711208');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-12)','01777711209');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-12)','01777711210');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-12)','01777711211');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-12)','01777711222');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-12)','01777711233');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-12)','01777711244');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-12)','01777711255');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-12)','01777711299');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-13)','01777711300');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-13)','01777711301');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-13)','01777711302');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-13)','01777711303');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-13)','01777711304');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-13)','01777711305');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-13)','01777711306');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-13)','01777711307');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-13)','01777711308');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-13)','01777711309');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-13)','01777711310');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-13)','01777711311');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-13)','01777711322');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-13)','01777711333');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-13)','01777711344');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-13)','01777711355');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-13)','01777711399');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Commanding Officer (RAB-14)','01777711400');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Seceond in Command (RAB-14)','01777711401');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adjutant (RAB-14)','01777711402');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Operations Officer (RAB-14)','01777711403');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Intelligence Officer (RAB-14)','01777711404');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ration & Logestic Officer (RAB-14)','01777711405');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('MTO (RAB-14)','01777711406');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Law Officer (RAB-14)','01777711407');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Media Officer (RAB-14)','01777711408');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medical Officer (RAB-14)','01777711409');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Duty Officer (RAB-14)','01777711410');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-1 (RAB-14)','01777711411');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-2 (RAB-14)','01777711422');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander CPC-3 (RAB-14)','01777711433');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Headquarters (RAB-14)','01777711444');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Company Commander Special (RAB-14)','01777711455');");
            db.execSQL("insert into "+DB_TABLE_RAB+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Control (RAB-14)','01777711499');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Upo Porichalok(Dhaka)','9556758');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Siddik Bazar Fire Station(Dhaka)','01730002210');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sodorghat Fire Station(Dhaka)','9534433');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sodorghat Nodi Fire Station(Dhaka)','7454055');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Postagola Fire Station(Dhaka)','01730002216');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lalbag Fire Station(Dhaka)','01730002218');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Polasi Barak Fire Station(Dhaka)','01730002219');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Khilgao Fire Station(Dhaka)','01730002225');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tejgao Fire Station(Dhaka)','01730002227');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mirpur Fire Station(Dhaka)','01730002229');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kurmitola Fire Station(Dhaka)','01730002232');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Uttora Fire Station(Dhaka)','01730082230');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('DPZ Fire Station(Dhaka)','01730002231');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Demra Fire Station(Dhaka)','01730002302');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Baridhara Fire Station(Dhaka)','01730002245');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shavar Fire Station(Dhaka)','01730002250');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dohar Fire Station(Dhaka)','01726845949');");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Hazaribag Fire Station(Dhaka)','01721733114')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dhamrai Fire Station(Dhaka)','01742302850')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Keranigong Fire Station(Dhaka)','01730002247')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Naranganj Fire Station(Naranganj)','01730002309')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Haziganj Fire Station(Naranganj)','01730002311')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bondor Fire Station(Naranganj)','01730002313')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Naranganj Nodi Fire Station(Naranganj)','01730002317')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Adamji Fire Station(Naranganj)','7691266')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Araihazar Fire Station(Naranganj)','01732939352')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Joidebpur Fire Station(Gajipur)','01730002122')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tongi Fire Station(Gajipur)','01730002130')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kaliyakoir Fire Station(Gajipur)','01744242248')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sripori Fire Station(Gajipur)','01770603808')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kaligonj Fire Station(Gajipur)','01743095858')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Munsigong Fire Station(Munsigong)','01730002142')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ghior Fire Station(Munsigong)','01730002386')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tangail Fire Station(Tangail)','01767609988')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Modhupur Fire Station(Tangail)','01729931191')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mirjapur Fire Station(Tangail)','01772169870')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Basayil Fire Station(Tangail)','01768070079')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sokhipur Fire Station(Tangail)','01790798686')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Nogapur Fire Station(Tangail)','01775424213')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Vuapur Fire Station(Tangail)','01731363000')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jamalpur Fire Station(Jamalpur)','01730002399')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sorishabari Fire Station(Jamalpur)','01744201952')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Islamipur Fire Station(Jamalpur)','01749809926')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Molandaho Fire Station(Jamalpur)','01768577373')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Serpur Fire Station(Serpur)','01730002187')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Nolitabari Fire Station(Serpur)','01771007210')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Maimansingha Fire Station(Maimansingha)','01730002353')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Muktagasa Fire Station(Maimansingha)','01730002356')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Issorgong Fire Station(Maimansingha)','01720020041')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kisorgong Fire Station(Kisorgong)','01730002372')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bajitpur Fire Station(Kisorgong)','01725771795')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Netrokona Fire Station(Netrokona)','01789744212')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mohongong Fire Station(Netrokona)','01730002381')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Faridpur Fire Station(Faridpur)','01558544300')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Vanga Fire Station(Faridpur)','01767923470')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Rajbari Fire Station(Rajbari)','01726595141')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Madaripur Fire Station(Madaripur)','01919800397')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sibachor Fire Station(Madaripur)','01881266200')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Gopalgong Fire Station(Gopalgong)','01713145084')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tungipara Fire Station(Gopalgong)','01754607172')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shoriatpur Fire Station(Shoriatpur)','01726877270')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Damudda Fire Station(Shoriatpur)','01927502592')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Borishal Fire Station(Borisal)','043171544')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Borishal Nodi Fire Station(Borisal)','043164000')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Pirojpur Fire Station(Pirojpur)','01724849080')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mothbaria Fire Station(Pirojpur)','01753233838')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jhalkathi Fire Station(Jhakathi)','049862518')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kathalia Fire Station(Jhakathi)','0173009061')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Vhola Fire Station(Vhola)','01714501896')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Monpura Fire Station(Vhola)','01990494689')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Potuakhali Fire Station(Potuakhali)','01777998333')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mirjagong Fire Station(Potuakhali)','01735090944')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Borguna Fire Station(Borguna)','01728604860')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Amtoli Fire Station(Borguna)','01744599094')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shyllet Fire Station(Shyllet)','01730009196')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jokigong Fire Station(Shyllet)','01760140757')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sunamgong Fire Station(Sunamgong)','01730009142')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Chatok Fire Station(Sunamgong)','01730009143')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Moulovibazar Fire Station(Moulovibazar)','01730009078')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shrimongol Fire Station(Moulovibazar)','01730009079')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Hobigang Fire Station(Hobigang)','01730082212')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Madhobpur Fire Station(Hobigang)','01730082213')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Rajshai Fire Station(Rajshai)','01730002502')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Durgapur Fire Station(Rajshai)','01733216532')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Chapaynobabgong Fire Station(Chapaynobabgong)','01730002515')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shibgong Fire Station(Chapaynobabgong)','01730002516')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Nouga Fire Station(Nouga)','01730002523')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Atray Fire Station(Nouga)','01730002529')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Nator Fire Station(Nator)','01730002518')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lalpur Fire Station(Nator)','01730002519')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bogura Fire Station(Bogura)','01730002497')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shonatola Fire Station(Bogura)','01730002498')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Joipurhat Fire Station(Joipurhat)','01730002539')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Akkelpur Fire Station(Joipurhat)','01743246424')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Pabna Fire Station(Pabna)','073162222')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sujanagar Fire Station(Pabna)','01758780970')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sirajgong Fire Station(Sirajgong)','01730002556')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ullahpara Fire Station(Sirajgong)','01730002556')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Rangpur Fire Station(Rangpur)','01732707172')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Haragacha Fire Station(Rangpur)','01730002564')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Gaibandha Fire Station(Gaibandha)','01730002582')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Gobindogong Fire Station(Gaibandha)','01706332525')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kurigram Fire Station(Kurigram)','01730082214')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ulipur Fire Station(Kurigram)','01730082214')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lalmonirhat Fire Station(Lalmonirhat)','01730009105')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Hatibandha Fire Station(Lalmonirhat)','01730009105')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Nilfamari Fire Station(Nilfamari)','01730009105')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Soyadpur Fire Station(Nilfamari)','01727785384')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dinajpur Fire Station(Dinajpur)','01730009120')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Fulbari Fire Station(Dinajpur)','01730009122')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Takurgao Fire Station(Takurgao)','01730009131')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Pirgong Fire Station(Takurgao)','01730009134')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Panchagor Fire Station(Ponchagor)','056861333')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tetulia Fire Station(Tetuia)','01720802578')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Tetulia Fire Station(Tetuia)','01720802578')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bondor Fire Station(Chittagong)','01730002420')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shitakundo Fire Station(Chittagong)','01730002428')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Patia Fire Station(Chittagong-Z2)','01730002430')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Chandanpur Fire Station(Chittagong-Z2)','01730002413')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kalurghat Fire Station(Chittagong-Z3)','01730002423')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Fotikchori Fire Station(Chittagong-Z3)','01772241510')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Cox-Bazar Fire Station(Cox-Bazar)','01730002434')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Pekua Fire Station(Cox-Bazar)','01730002442')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bandarban Fire Station(Bandarban)','01730002460')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lama Fire Station(Bandarban)','01739183468')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Rangamati Fire Station(Rangamati)','01730002462')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kaptai Fire Station(Rangamati)','01730002463')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Khagrachori Fire Station(Khagrachori)','01730002454')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ramgor Fire Station(Khagrachori)','01820705177')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Comilla Fire Station(Comilla)','08165090')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('EPZ Fire Station(Comilla)','01730002470')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Akhrao Fire Station(Brahmonbaria)','01730002483')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Koshba Fire Station(Brahmonbaria)','01745481244')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Cadpur Fire Station(Cadpur)','01730002485')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kochua Fire Station(Cadpur)','01728546110')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mayzdi Fire Station(Noakhai)','01730002489')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Sonaymuri Fire Station(Noakhai)','01865126289')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lakhipur Fire Station(Lakhipur)','01730002495')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Ramgoti Fire Station(Lakhipur)','01749452245')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Feni Fire Station(Feni)','01730002492')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Chagolnaiya Fire Station(Feni)','01825061404')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Khulna Nodi Fire Station(Khulna)','01730009151')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Rupsha Fire Station(Khulna)','0702456200')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bagerhat Fire Station(Bagerhat)','046863666')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('EPZ Fire Station(Bagerhat)','01759856385')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Shatkhira Fire Station(Shatkhira)','01772966736')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Joshor Fire Station(Joshor)','042165114')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Benapol Fire Station(Joshor)','01730009171')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Noray Fire Station(Norayl)','048162222')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Lohagara Fire Station(Norayl)','01834185747')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Magura Fire Station(Magura)','01730009185')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jhinaidah Fire Station(Jhinaidah)','01717967188')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kaligong Fire Station(Jhinaidah)','01777569056')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Kustia Fire Station(Kustia)','0173320385')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Khoksa Fire Station(Kustia)','0702456200')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Chadanga Fire Station(Chadanga)','01745400699')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Jibnagar Fire Station(Chadanga)','01776250140')");
            db.execSQL("insert into "+DB_TABLE_FIRE_SERVICE+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Mhetpur Fire Station(Meherpur)','01971020209')");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dhaka City Corporation Ambulance(Nagar Bhaban)','9556018');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Day - Night Ambulance Service(Nagar Bhaban)','0171544328');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Combined Military Hospital(CMH)-Dhaka','8822779');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Diabetic Hospital(BIRDEM)','9661551');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Fire Service Ambulance,Dhaka','9555555');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Red Crescent Ambulance-Dhaka ','9358799');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Square Hospital','8144488');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('National Heart Institute & Hospital','9122560');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Al-Markazul Islami Ambulance Service','8114980');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Anjuman-E-Mufidul Islam','9336611');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Apollo Hospital-Dhaka','01714-090000');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bangabandhu Sheikh Mujib Medical University','8614545');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Bangladesh Medical College Hospital','9120793');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Children Hospital','8116061');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dhaka City Corporation Ambulance(Mirpur)','9004738');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dhaka Medical College Hospital','8626812');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Dhaka Renal Centre & Genera Hospital','8610928');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Holy Family RC Hospital','8311721');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Islamia Optical Hospital ','9119315');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Medinova Medical Service Ltd.','86918583');");
            db.execSQL("insert into "+DB_TABLE_HOSPITAL+"("+NAME_COLUMN+","+PHONE_NUMBER_COLUM+") values('Monowara Hospital (pvt.)Ltd. ','8318529');");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            ourDatabase.execSQL("DROP TABLE IF EXISTS "+DB_TABLE_POLICE+";");
            ourDatabase.execSQL("DROP TABLE IF EXISTS "+DB_TABLE_HOSPITAL+";");
            ourDatabase.execSQL("DROP TABLE IF EXISTS "+DB_TABLE_RAB+";");
            ourDatabase.execSQL("DROP TABLE IF EXISTS "+DB_TABLE_POLICE+";");

        }
    }
    private List<ContentValues> getContentListByTableName(String tableName){
        List<ContentValues> result = new LinkedList<>();
        String columns[] = {NAME_COLUMN,PHONE_NUMBER_COLUM};
        Cursor query = ourDatabase.query(tableName, columns, null, null, null, null,null);
        int nameIndexId = query.getColumnIndex(NAME_COLUMN);
        int phoneNumberIndexId = query.getColumnIndex(PHONE_NUMBER_COLUM);
        for(query.moveToFirst();!query.isAfterLast();query.moveToNext()){
            String name = query.getString(nameIndexId);
            String phoneNumber = query.getString(phoneNumberIndexId);
            ContentValues temp = new ContentValues();
            temp.put(NAME_COLUMN,name);
            temp.put(PHONE_NUMBER_COLUM,phoneNumber);
            result.add(temp);
        }
        return result;
    }
    //overloaded to get by string key
    private List<ContentValues> getContentListByTableName(String tableName,String key){
        List<ContentValues> result = new LinkedList<>();
        String columns[] = {NAME_COLUMN,PHONE_NUMBER_COLUM};
        String selection[] ={"%"+key+"%"};
        Cursor query = ourDatabase.query(tableName, columns, NAME_COLUMN+" LIKE ?", selection, null, null,null);
        int nameIndexId = query.getColumnIndex(NAME_COLUMN);
        int phoneNumberIndexId = query.getColumnIndex(PHONE_NUMBER_COLUM);
        for(query.moveToFirst();!query.isAfterLast();query.moveToNext()){
            String name = query.getString(nameIndexId);
            String phoneNumber = query.getString(phoneNumberIndexId);
            ContentValues temp = new ContentValues();
            temp.put(NAME_COLUMN,name);
            temp.put(PHONE_NUMBER_COLUM,phoneNumber);
            result.add(temp);
        }
        return result;
    }
    private void insertByTableName(String tableName,String name,String phoneNumber){
        ContentValues temp = new ContentValues();
        temp.put(NAME_COLUMN,name);
        temp.put(PHONE_NUMBER_COLUM,phoneNumber);
        ourDatabase.insert(tableName,null,temp);
    }
    private void deleteByTableName(String tableName){
        ourDatabase.delete(tableName,null,null);
    }

    public List<ContentValues> getPolice() throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_POLICE);
        return result;
    }

    public List<ContentValues> getFireService() throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_FIRE_SERVICE);
        return result;
    }
    public List<ContentValues> getRab() throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_RAB);
        return result;
    }
    public List<ContentValues> getHospital() throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_HOSPITAL);
        return result;
    }



    //overoaded insert operation for search

    public List<ContentValues> getPolice(String key) throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_POLICE,key);
        return result;
    }

    public List<ContentValues> getFireService(String key) throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_FIRE_SERVICE,key);
        return result;
    }
    public List<ContentValues> getRab(String key) throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_RAB,key);
        return result;
    }
    public List<ContentValues> getHospital(String key) throws SQLException{
        List<ContentValues> result = new LinkedList<>();
        result = getContentListByTableName(DB_TABLE_HOSPITAL,key);
        return result;
    }
    //end of overload








    public void insertPolice(String name,String phoneNumber) throws SQLException{
        insertByTableName(DB_TABLE_POLICE,name,phoneNumber);
    }
    public void insertFireService(String name,String phoneNumber) throws SQLException{
        insertByTableName(DB_TABLE_FIRE_SERVICE,name,phoneNumber);
    }
    public void insertRAB(String name,String phoneNumber) throws SQLException{
        insertByTableName(DB_TABLE_RAB,name,phoneNumber);
    }
    public void insertHospital(String name,String phoneNumber) throws SQLException{
        insertByTableName(DB_TABLE_HOSPITAL,name,phoneNumber);
    }

    public void deletePoliceTable() throws SQLException{
        deleteByTableName(DB_TABLE_POLICE);
    }
    public void deleteFireServiceTable() throws SQLException{
        deleteByTableName(DB_TABLE_FIRE_SERVICE);
    }
    public void deleteRABTable() throws SQLException{
        deleteByTableName(DB_TABLE_RAB);
    }
    public void deleteHospitalTable() throws SQLException{
        deleteByTableName(DB_TABLE_HOSPITAL);
    }
    public AppDatabase(Context c){
        ourContext = c;
    }
    public AppDatabase open(){
        dbHelper = new DbHelper(ourContext);
        ourDatabase = dbHelper.getWritableDatabase();
        return this;
    }
    public void close(){
        dbHelper.close();
    }

}
