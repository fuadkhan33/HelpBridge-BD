package com.fuadkhan.helpbridgedhaka;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.LinkedList;
import java.util.List;

public class PoliceActivity extends AppCompatActivity {


    private ListView mPoliceListView ;
    private AppDatabase database;
    private EditText mSearchPoliceETxt;
    private List<ContentValues> policeConetent = new LinkedList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_police);
        mPoliceListView = (ListView) findViewById(R.id.mListPolice);
        mSearchPoliceETxt = (EditText) findViewById(R.id.mSearchPoliEt);

        //fetch data from database
        try {
            database = new AppDatabase(this);
            database.open();
            policeConetent = database.getPolice();
            database.close();
        } catch (Exception e) {
            Log.d("SQL", e.getMessage().toString());
        }
        refreshList();
        mSearchPoliceETxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                try {
                    database.open();
                    policeConetent = database.getPolice(mSearchPoliceETxt.getText().toString().trim());
                    if(mSearchPoliceETxt.getText().toString().isEmpty()){
                        policeConetent = database.getPolice();
                    }
                    database.close();
                } catch (Exception e){
                    Log.d("sql",e.getMessage().toString());
                }
                refreshList();
                Log.d("ct","ct");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
    public void refreshList(){
        //adapter to list view
        ArrayAdapter<ContentValues> adapter = new ArrayAdapter<ContentValues>(this, R.layout.list_view, policeConetent){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if(convertView==null){
                    convertView = getLayoutInflater().inflate(R.layout.list_view,parent,false);
                }
                ContentValues temp = policeConetent.get(position);
                ((TextView) convertView.findViewById(R.id.mlistNameTextView)).setText(temp.getAsString(database.NAME_COLUMN));
                ((TextView) convertView.findViewById(R.id.mListPhoneTextView)).setText(temp.getAsString(database.PHONE_NUMBER_COLUM));
                final String phoneNumber = temp.getAsString(database.PHONE_NUMBER_COLUM);
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+phoneNumber.trim()));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try{
                            getApplicationContext().startActivity(intent);
                        } catch (Exception e){
                            Log.d("error",e.getMessage().toString());
                        }

                    }
                });
                return convertView;
            }
        };
        mPoliceListView.setAdapter(adapter);
        //end of listview connectivity
    }

}
